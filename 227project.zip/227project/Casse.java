
import java.util.Scanner ;


public class Casse { 
    public static void main(String[] args){
   Scanner input = new Scanner(System.in);
   int n ; 
   int m ; 
     System.out.println("Enter The Value Of n"); 
                    n = input.nextInt();
    
         System.out.println("Enter The Value Of m"); 
                              
                                 m = input.nextInt();

while(n < 3 || n > 6 ){
     System.out.println("The Value Of n Violates The Conditions Re enter  "); 
                    n = input.nextInt();
     } 
     
             while( (n*n) <= m ){
     System.out.println("The Value Of m Violates The Conditions Re enter  "); 
                    m = input.nextInt();
     }
     
     int[][] Narray = new int[n][n] ; 
     
     
     for(int j = 0 ; j < n ; j++){
    
for(int i = 0 ; i < n ; i++)
Narray[j][i]=1;             }      

 
     for(int j = 0 ; j < n ; j++){
    
for(int i = 0 ; i < n ; i++)
   System.out.print(Narray[j][i]+ "  " );    
    System.out.println();       }     //PRINTING  

    

       System.out.println(1%2);   


      
        int k=0 , h=0;
        for(int i=0;i<=m ;i++){
            k=(int)(Math.random() *n);
         h=(int)(Math.random() * n);
   if( Narray[k][h]==1) 
        Narray[k][h]=0;
        }//making random slots zeroes 



     for(int j = 0 ; j < n ; j++){
    
for(int i = 0 ; i < n ; i++)
   System.out.print(Narray[j][i]+ "  " );    
    System.out.println();       }     //PRINTING 

    }
}